</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="../inc/js/sweetalert.js"></script>
<script src="../inc/js/core.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        $("time.timeago").timeago();
    });
</script>
</body>
</html>