<?php include '../inc/php/header.php'; ?>
<!--
<script>
    $(function () {
        $('#menu1').metisMenu();
    });
</script>
-->
<?php include '../inc/php/footer.php'; ?>