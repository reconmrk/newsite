<?php
header('Location: dashboard/dashboard.php');